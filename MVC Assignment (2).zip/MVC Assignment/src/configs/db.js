const mongoose = require("mongoose");

module.exports = () => {
    return mongoose.connect("mongodb+srv://tanmoy:tanmoy_123@cluster0.22r1x.mongodb.net/mvc?retryWrites=true&w=majority");
};