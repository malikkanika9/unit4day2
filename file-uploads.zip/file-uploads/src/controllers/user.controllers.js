const express = require("express");

const User = require("../models/user.models");

// const { uploadFiles } = require("../middlewares/uploads");
const upload = require("../middlewares/uploads")

const router = express.Router();

router.get("", async (req, res) => {
  try {
    const users = await User.find().lean().exec();

    return res.status(200).send(users);
  } catch (err) {
    return res.status(500).send({ message: err.message });
  }
});

router.post("", upload.single("profilePic"), async (req, res) => {
  try {
    
    const user = await User.create({
      firstName: req.body.firstName,
      profilePic: req.file.path,
    });
    return res.status(200).send(user);
  } catch (err) {
    return res.status(500).send({ message: err.message });
  }
});

router.post("/multiple", upload.any("gallery",5), async (req, res) => {
  try {
    const filePaths = req.files.map((file) => {
      return file.path;
    });

    const user = await User.create({
      firstName: req.body.firstName,
      gallery: filePaths,
    });

    return res.status(200).send(user);
  } catch (err) {
    return res.status(500).send({ message: err.message });
  }
});

router.put("", upload.single('profilePic'), (req, res) => {
  const id = req.params.id;

const body = req.body;

console.log('body:', body);
console.log('req:', req);

const profilePic = req.file.filename;

Post.findOneAndUpdate(id,
{
  $set: {
    profilePic
  }
},
{ new: true }
).then(post => {
  req.flash('success', 'Edits submitted successfully');
  res.redirect('/posts');
})
.catch(err => {
  return req.flash('error', 'Unable to edit article');
}); });
router.delete("", async (req, res) => {
  try {
    const post = await users.findByIdAndDelete(req.params.id).lean().exec();

    return res.status(200).send(post);
  } catch (err) {
    return res.status(500).send({ message: err.message });
  }
});

router.delete("",function (req, res) {
  message : "Error! in image upload.";
    if (!req.params.profilePic) {
        console.log("No file received");
        message = "Error! in image delete.";
        return res.status(500).json('error in delete');
    
      } else {
        console.log('file received');
        console.log(req.params.profilePic);
        try {
            fs.unlinkSync(DIR+'/'+req.params.profilePic+'.png');
            console.log('successfully deleted /tmp/hello');
            return res.status(200).send('Successfully! Image has been Deleted');
          } catch (err) {
            // handle the error
            return res.status(400).send(err);
          }
        
      }
 
});

module.exports = router;
